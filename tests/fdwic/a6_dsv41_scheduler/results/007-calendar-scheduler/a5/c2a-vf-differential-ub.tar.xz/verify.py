from pathlib import Path
import numpy as np
import hashlib,json
r=Path(__file__).resolve().parent
D=[];failures=[]
def sha(a):return hashlib.sha256(a).hexdigest()
def u16(a,i,n):return np.frombuffer(a,dtype='<u2',count=n,offset=i).copy()
def bfread(a,i,n):return (u16(a,i,n).astype('u4')<<16).view('f4')
def f32(a,i,n):return np.frombuffer(a,dtype='<f4',count=n,offset=i)
def bf(x):
    v=np.asarray(x,dtype='f4').view('u4')
    return (((v+32767+((v>>16)&1))>>16)<<16).view('f4')
def quant(x,tie_even=False):
    thresholds=np.array([.25,.75,1.25,1.75,2.5,3.5,5.],dtype='f4')
    c=sum(((np.abs(x)>=v) if tie_even and k%2 else (np.abs(x)>v)).astype('u1') for k,v in enumerate(thresholds))
    c |= (np.signbit(x).astype('u1')<<3)
    return (c[::2] | (c[1::2]<<4))
for case in (r/'cases.txt').read_text().splitlines():
    v,n,name=case.split();v=int(v);n=int(n);base=r/'records'/name
    raw=(base.with_suffix('.in')).read_bytes(); ref=(base.with_suffix('.reference')).read_bytes(); cand=(base.with_suffix('.candidate')).read_bytes()
    a,c,init=(np.frombuffer(z,np.uint8) for z in (ref,cand,raw))
    delta=np.where(a!=c)[0]; modified=np.flatnonzero(a!=init)
    if v==0:
        regions=[(13312,15360),(15360,16384),(16384,17408)]
    elif v==1: regions=[(16384+896,17408),(1024,3072),(3072,3328),(9216,9280)]
    else: regions=[(1024+i*256,1024+i*256+64) for i in range(n)]+[(3072+i*256,3072+i*256+4) for i in range(n)]
    allowed=np.zeros(len(a),np.bool_)
    for s,e in regions:allowed[s:e]=True
    guard=np.count_nonzero((init!=a)&~allowed)
    rec={'case':name,'rows':n,'input_sha256':sha(raw),'reference_sha256':sha(ref),'candidate_sha256':sha(cand),'checked_UB_bytes':len(a),'differing_UB_bytes':len(delta),'changed_reference_bytes':len(modified),'reference_guard_writes':int(guard),'first_differing_offsets':delta[:12].tolist(),'written_region_sha256':sha(a[allowed].tobytes())}
    if len(delta) or not len(modified) or guard:failures.append(name)
    if v==0:
        lx=u16(ref,15360,512);lu=u16(ref,16384,512);rec['nonzero_BF16_latents']=int(np.count_nonzero(lx & 0x7fff))
        if not np.array_equal(lx,lu) or not rec['nonzero_BF16_latents']:failures.append(name)
    if v==0 and name!='pool-mixed':
        target=bf(f32(raw,1024 if name=='pool-dominant-b' else 5120,512))
        pooled=f32(ref,13312,512)
        rec['oracle_pooled_diff_values']=int(np.sum(target!=pooled))
        if rec['oracle_pooled_diff_values']:failures.append(name+' oracle')
    if v==1:
        vals=bfread(ref,16384,512); scales=bfread(ref,9216,32)
        expected_sc=bf(np.maximum(np.float32(1/512),np.max(np.abs(vals).reshape(32,16),axis=1)*np.float32(1/6)))
        rec['unique_BF16_scales']=np.unique(scales).tolist()
        expected=quant(vals/np.repeat(expected_sc,16))
        rec['oracle_payload_diff_bytes']=int(np.sum(expected!=a[3072:3328]));rec['oracle_scale_diff']=int(np.sum(scales!=expected_sc))
        if rec['oracle_payload_diff_bytes'] or rec['oracle_scale_diff']:failures.append(name+' oracle')
    if v==2:
        rec['first_row_scale_codes']=a[3072:3076].tolist()
        if name=='idx-exact':
            w=bfread(raw,5376,128)
            scale=w[:64]; coded=np.repeat(np.array([1,.5],np.float32),32)
            expected=quant(scale/coded,True)
            rec['oracle_first32bytes_diff']=int(np.sum(expected!=a[1024:1056]))
            if rec['oracle_first32bytes_diff']:failures.append(name+' oracle')
    D.append(rec);print(name,'diff',len(delta),'guard',guard,'modified',len(modified),rec.get('oracle_payload_diff_bytes'),rec.get('oracle_first32bytes_diff'))
(r/'results.json').write_text(json.dumps({'hardware_log':'worker-onboard.log','cases':D,'failures':failures},indent=2))
if failures:raise SystemExit(failures)
