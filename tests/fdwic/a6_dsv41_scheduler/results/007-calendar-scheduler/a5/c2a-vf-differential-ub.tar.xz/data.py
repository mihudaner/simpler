import hashlib,json,sys
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent; out=root/'records';out.mkdir(exist_ok=True)
rng=np.random.default_rng(20261127)
cases=[]
def bfcode(x):
    x=np.asarray(x,np.float32).view(np.uint32)
    return ((x+np.uint32(32767)+((x>>16)&1))>>16).astype('<u2')
def bfval(x): return (np.asarray(x,np.uint32)<<16).view(np.float32)
def put(a,at,x,dtype): a[at:at+len(np.asarray(x).tobytes())]=np.frombuffer(np.asarray(x,dtype=dtype).tobytes(),np.uint8)
def f(a,at,x):put(a,at,np.asarray(x,dtype='<f4'),'<f4')
def b(a,at,x):put(a,at,bfcode(x),'<u2')
def base(): return rng.integers(0,256,18432,dtype=np.uint8)
def store(v,rows,name,a): (out/(name+'.in')).write_bytes(a.tobytes()); cases.append((v,rows,name))
edges=np.array([-.0,.25,-.75,1.25,-1.75,2.5,-3.5,5.,-5.,3.5,-2.5,1.75,-1.25,.75,-.25,6.],np.float32)
for i in range(4):
    a=base(); w=rng.uniform(.2,2,512).astype('f4'); b(a,0,w)
    x=rng.normal(size=512).astype('f4');y=rng.normal(size=512).astype('f4')
    u=rng.normal(0,2,512).astype('f4');v=rng.normal(0,2,512).astype('f4')
    if i==1: u[:]=125;v[:]=-95
    if i==2: u[:]=-82;v[:]=114
    if i==3: u[:]=v[:]=0;x=y=np.tile(edges,32)
    f(a,1024,y); f(a,3072,v);f(a,5120,x);f(a,7168,u)
    store(0,1,['pool-mixed','pool-dominant-a','pool-dominant-b','pool-equal'][i],a)
for i in range(4):
    a=base()
    x=np.tile(edges,32).reshape(32,16)
    if i==1:
        codes=bfcode(x);si=np.signbit(x)
        for g in range(32): codes[g,:15] += np.uint16((1 if g%2 else -1)%65536)
        codes[:,0]=0x8000;x=bfval(codes)
    factors=np.resize(np.array([1,0.5,2,0.001953125,0.000244140625,8,32,0.0625],np.float32),32)
    x=(x*factors[:,None]).reshape(512)
    if i<2:
        c=np.ones(32,dtype='f4'); s=np.zeros(32,dtype='f4')
    else:
        x=rng.normal(0,1.3,512).astype('f4');angle=rng.uniform(-3,3,32); c=np.cos(angle).astype('f4'); s=np.sin(angle).astype('f4')
    b(a,16384,x); f(a,5120,c);f(a,7168,s)
    store(1,1,['fp4-exact','fp4-neighbors','fp4-rope-a','fp4-rope-b'][i],a)
for i,rows in enumerate((1,8,5,7)):
    a=base()
    if i==0:
        weight=np.tile(edges,8)*np.repeat(np.array([1,.5,2,8],np.float32),32)
        x=np.ones(8*128,np.float32); angle=np.zeros(8*32,np.float32)
    elif i==1:
        weight=np.resize(np.array([.25,-.75,1.25,1.75,-2.5,3.5,5.,6.],np.float32),128)*np.repeat(np.array([1,.5,2,8],np.float32),32)
        x=np.ones(8*128,np.float32);angle=rng.uniform(-2.8,2.8,8*32).astype('f4')
    else:
        weight=rng.uniform(.25,1.75,128);x=rng.normal(0,1.25,8*128);angle=rng.uniform(-3,3,8*32)
    b(a,5376,weight);b(a,5632,x);f(a,7680,np.cos(angle).astype('f4'));f(a,0,np.sin(angle).astype('f4'))
    store(2,rows,['idx-exact','idx-eight-rows','idx-five-rows','idx-seven-rows'][i],a)
(root/'cases.txt').write_text(''.join(f'{v} {n} {name}\n' for v,n,name in cases))
