#include <pto/pto-inst.hpp>
#include "tensor.h"
#if CANDIDATE
#define kernel_entry old_kernel_entry
#if VF < 2
#include "_c2a_compress__2.cpp"
#else
#include "idx_k_norm_rope_publish.cpp"
#endif
#undef kernel_entry
#else
extern "C" __aicore__ void __pypto_vf__c2a_compress__2_0(__ubuf__ bfloat16_t *);
extern "C" __aicore__ void __pypto_vf__c2a_compress__2_1(__ubuf__ float *);
extern "C" __aicore__ void __pypto_vf_idx_k_norm_rope_publish_0(__ubuf__ float *, int64_t);
#endif
using namespace pto;
extern "C" __aicore__ void kernel_entry(__gm__ int64_t *args) {
    auto *input_arg = reinterpret_cast<__gm__ Tensor *>(args[0]);
    auto *output_arg = reinterpret_cast<__gm__ Tensor *>(args[1]);
    auto *src = reinterpret_cast<__gm__ uint8_t *>(input_arg->buffer.addr)+input_arg->start_offset;
    auto *dst = reinterpret_cast<__gm__ uint8_t *>(output_arg->buffer.addr)+output_arg->start_offset;
    uint64_t rows=args[2];
    set_atomic_none();
    set_mask_norm();
    set_vector_mask(-1,-1);
    constexpr int Bytes = 18432;
    Tile<TileType::Vec,uint8_t,1,Bytes> scratch;
    TASSIGN(scratch,0);
    using G = GlobalTensor<uint8_t,TileShape2D<uint8_t,1,Bytes>,BaseShape2D<uint8_t,1,Bytes>>;
    G input(src), output(dst);
    TLOAD(scratch,input);
    set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0); wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
#if VF == 0
    __pypto_vf__c2a_compress__2_0((__ubuf__ bfloat16_t *)scratch.data());
#elif VF == 1
    __pypto_vf__c2a_compress__2_1((__ubuf__ float *)(scratch.data()+1024));
#else
    __pypto_vf_idx_k_norm_rope_publish_0((__ubuf__ float *)scratch.data(),rows);
#endif
    set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0); wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
    TSTORE(output,scratch);
    pipe_barrier(PIPE_ALL);
}
